import { createContext } from "react";

const UsersContext = createContext();

export default UsersContext;
