import { createContext } from "react";

const FiltersContext = createContext();

export default FiltersContext;
