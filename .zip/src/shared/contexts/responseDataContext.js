import { createContext } from "react";

const ResponseDataContext = createContext();

export default ResponseDataContext;
