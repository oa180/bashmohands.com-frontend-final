export default function SessionPage() {
  return <h1>Single Session</h1>;
}
