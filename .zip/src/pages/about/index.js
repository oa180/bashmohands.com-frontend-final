export default function AboutPage() {
  return <div>About Page</div>;
}
